package com.mjr.cortecerto.Tools;

public class LocationData {
    String latitude;
    String longitude;

    public LocationData(String latitude, String longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }
}
